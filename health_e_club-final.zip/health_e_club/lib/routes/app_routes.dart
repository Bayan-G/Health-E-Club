/*
 * Copyright (c) 2022   omnni
 */

class Routes {
  static const login = '/login';
  static const ForgetPassword = '/ForgetPassword';
  static const Wrapper = '/Wrapper';
  static const home = '/home';
  static const register = '/register';
  static const error = '/error';
  static const Edit_or_Delete_appointment = '/Edit_or_Delete_appointment';

  static const diease = '/diease';
  static const BookAnAppointmentScreen = '/BookAnAppointmentScreen';
  static const chat = '/chat';
  static const Chats_live = '/Chats_live';
  static const PatientAppointment = '/PatientAppointment';
  static const profile = '/profile';
  static const Group = '/Group';
  static const doctor_profile = '/doctor_profile';
  static const Choos_doctor = '/Choos_doctor';
  static const Support = '/Support';
  static const Insert_appointment = '/Insert_appointment';
  static const vieryemail = '/vieryemail';

}
