
class DiseaseModel {
  String? photo;
  String? name;

  DiseaseModel({
    required this.name,
    required this.photo,
  });
}
