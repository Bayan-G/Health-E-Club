

class SupportModel {
  SupportModel({
    required this.title,
    required this.subtitle,
  });

  String? title;
  String? subtitle;
}
