final String IMAGE_PATH_FOLDER = 'assets/images/';

class Assets {

  static final Assets shared = Assets();

  // TODO: Images

  // TODO: Icons
  final String male = IMAGE_PATH_FOLDER + "1.png";
  final String Logo = IMAGE_PATH_FOLDER + "2.png";
  final String female = IMAGE_PATH_FOLDER + "3.png";
  final String register = IMAGE_PATH_FOLDER + "4.png";
  final String person_profile = IMAGE_PATH_FOLDER + "5.png";
  final String my_profile = IMAGE_PATH_FOLDER + "6.png";
  final String Appointments  = IMAGE_PATH_FOLDER + "7.png";
  final String chat  = IMAGE_PATH_FOLDER + "8.png";
  final String home  = IMAGE_PATH_FOLDER + "9.png";
  final String logout  = IMAGE_PATH_FOLDER + "10.png";
  final String add  = IMAGE_PATH_FOLDER + "11.png";
  final String group   = IMAGE_PATH_FOLDER + "12.png";
  final String Consultation  = IMAGE_PATH_FOLDER + "13.png";
  final String Diabetes  = IMAGE_PATH_FOLDER + "14.png";
  final String password  = IMAGE_PATH_FOLDER + "15.png";
  final String date  = IMAGE_PATH_FOLDER + "16.png";
  final String email  = IMAGE_PATH_FOLDER + "17.png";
  final String license  = IMAGE_PATH_FOLDER + "18.png";
  final String phone  = IMAGE_PATH_FOLDER + "19.png";
  final String experience  = IMAGE_PATH_FOLDER + "20.png";
  final String user  = IMAGE_PATH_FOLDER + "21.png";
  final String Dermatologist  = IMAGE_PATH_FOLDER + "22.png";
  final String back = IMAGE_PATH_FOLDER + "23.png";
  final String search = IMAGE_PATH_FOLDER + "24.png";
  final String heart = IMAGE_PATH_FOLDER + "25.png";
  final String hand = IMAGE_PATH_FOLDER + "26.png";
  final String meter = IMAGE_PATH_FOLDER + "27.png";
  final String obstetrics = IMAGE_PATH_FOLDER + "28.png";
  final String lungs = IMAGE_PATH_FOLDER + "29.png";
  final String kidney = IMAGE_PATH_FOLDER + "30.png";
  final String blood_disease = IMAGE_PATH_FOLDER + "31.png";
  final String Gastrointestinal_tract = IMAGE_PATH_FOLDER + "32.png";
  final String success = IMAGE_PATH_FOLDER + "33.png";
  final String omni = IMAGE_PATH_FOLDER + "omni.png";
  final String edit_booking = IMAGE_PATH_FOLDER + "34.png";
  final String edit_booking1 = IMAGE_PATH_FOLDER + "35.png";
  final String edit_booking2 = IMAGE_PATH_FOLDER + "36.png";
  final String support = IMAGE_PATH_FOLDER + "37.png";
  final String language = IMAGE_PATH_FOLDER + "38.JPG";
}