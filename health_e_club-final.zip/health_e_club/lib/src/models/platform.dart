enum Platform { iOS, other } //other indicates for web and android
