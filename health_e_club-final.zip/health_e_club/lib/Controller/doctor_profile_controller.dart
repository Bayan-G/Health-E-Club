import 'package:get/get.dart';

class doctor_profilecontroller extends GetxController {


}
