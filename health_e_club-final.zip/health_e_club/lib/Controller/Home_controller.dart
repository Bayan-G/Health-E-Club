/*
 * Copyright (c) 2022   omnni
 */

import 'package:flutter/cupertino.dart';
import 'package:health_e_club/Controller/register_controller.dart';



class homeController extends registerController {


  onInit() async {


    super.onInit();
  }

}
