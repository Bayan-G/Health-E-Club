/*
 * Copyright (c) 2022   omnni
 */

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';


class MyAppController extends GetxController {


  onInit() async {
    super.onInit();
  }

}
