import 'package:flutter/material.dart';
import 'package:get/get.dart';


class doctorController extends GetxController {
  Rx<TextEditingController> searchTextField = TextEditingController().obs;


}
