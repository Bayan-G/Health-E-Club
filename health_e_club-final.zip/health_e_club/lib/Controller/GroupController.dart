import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class GroupController extends GetxController {

  Rx<TextEditingController> searchTextField = TextEditingController().obs;

}
