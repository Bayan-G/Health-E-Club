enum UserType {
  doctor,
  Patient,
}
