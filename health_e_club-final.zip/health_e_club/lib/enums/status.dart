enum Status { ACTIVE, Finished, canceled }
