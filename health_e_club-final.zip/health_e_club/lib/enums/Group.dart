enum group {
  Heart_Disease,
  Skin_diseases,
  Diabetes_diseases,
  obstetrics_and_Gynecology,
  Lung_diseases,
  kidneys_diseases,
  Blood_pressure_disease,
  Gastrointestinal_tract,
  chat
}
