package com.example.health_e_club

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
